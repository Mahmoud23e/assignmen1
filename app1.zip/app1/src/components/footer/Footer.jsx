export default function Footer() {
  return (
    <>
      <div className=" grid md:grid-cols-3 p-10  bg-[#2c3f50] text-white">
        <div className="left text-center ">
          <p className="text-[25px] font-bold">LOCATION</p>
          <p>2215 John Daniel Drive</p>
          <p>Clark, MO 65243</p>
        </div>
        <div className="mid text-center font-bold text-[25px]">
          <div className="top">AROUND THE WEB</div>

          <div className="prands text-center ">
            <i className="fa-brands fa-facebook     ms-5 "></i>
            <i className="fa-brands fa-twitter     ms-5"></i>
            <i className="fa-brands fa-linkedin     ms-5 "></i>
            <i className="fa-solid fa-globe     ms-5 "></i>
          </div>
        </div>
        <div className="right text-center">
          <p className="text-[25px] font-bold">ABOUT FREELANCER</p>
          <p>Freelance is a free to use, licensed Bootstrap theme </p>
          <p>created by Route</p>
        </div>
      </div>
      <div className="copyRight bg-slate-800 text-white text-center p-8 font-bold">
        Copyright © Your Website 2021
      </div>
    </>
  );
}
