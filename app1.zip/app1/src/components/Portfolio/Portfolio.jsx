import img1 from "../../assets/images/poert1.png";
import img2 from "../../assets/images/port2.png";
import img3 from "../../assets/images/port3.png";

export default function Portfolio() {
  return (
    <div className="portfolio text-center">
      <div className="top text-center flesx flex-col justify-center items-center">
        <p className=" font-bold text-[35px] text-slate-700">
          PORTFOLIO COMPONENT
        </p>
        <div className="star flex justify-center mb-2">
          <div className="left w-[100px] h-1 bg-slate-700  rounded-md mt-2"></div>
          <i className="fa-solid fa-star mx-2"></i>
          <div className="left w-[100px] h-1 bg-slate-700  rounded-md mt-2"></div>
        </div>
      </div>
      <div className="cards container mx-auto grid lg:grid-cols-3">
        <div className="card relative group  m-2">
          <img
            src={img1}
            className="w-full  rounded-[10px]"
            alt="house_image"
          />
          <div className="layer justify-center items-center rounded-md flex opacity-0 w-full bg-[#1abc9ce6]  h-[100%] absolute top-0  left-0 z-10  group-hover:opacity-100 transition duration-500 cursor-pointer  ">
            <i className="  text-white text-[90px] fa-solid fa-plus"></i>
          </div>
        </div>
        <div className="card relative group  m-2">
          <img
            src={img2}
            className="w-full  rounded-[10px]"
            alt="house_image"
          />
          <div className="layer justify-center items-center rounded-md flex opacity-0 w-full bg-[#1abc9ce6]  h-[100%] absolute top-0  left-0 z-10  group-hover:opacity-100 transition duration-500 cursor-pointer  ">
            <i className="  text-white text-[90px] fa-solid fa-plus"></i>
          </div>
        </div>
        <div className="card relative group  m-2">
          <img
            src={img3}
            className="w-full  rounded-[10px]"
            alt="house_image"
          />
          <div className="layer justify-center items-center rounded-md flex opacity-0 w-full bg-[#1abc9ce6]  h-[100%] absolute top-0  left-0 z-10  group-hover:opacity-100 transition duration-500 cursor-pointer  ">
            <i className="  text-white text-[90px] fa-solid fa-plus"></i>
          </div>
        </div>

        <div className="card relative group  m-2">
          <img
            src={img1}
            className="w-full  rounded-[10px]"
            alt="house_image"
          />
          <div className="layer justify-center items-center rounded-md flex opacity-0 w-full bg-[#1abc9ce6]  h-[100%] absolute top-0  left-0 z-10  group-hover:opacity-100 transition duration-500 cursor-pointer  ">
            <i className="  text-white text-[90px] fa-solid fa-plus"></i>
          </div>
        </div>
        <div className="card relative group  m-2">
          <img
            src={img2}
            className="w-full  rounded-[10px]"
            alt="house_image"
          />
          <div className="layer justify-center items-center rounded-md flex opacity-0 w-full bg-[#1abc9ce6]  h-[100%] absolute top-0  left-0 z-10  group-hover:opacity-100 transition duration-500 cursor-pointer  ">
            <i className="  text-white text-[90px] fa-solid fa-plus"></i>
          </div>
        </div>
        <div className="card relative group  m-2">
          <img
            src={img2}
            className="w-full  rounded-[10px]"
            alt="house_image"
          />
          <div className="layer justify-center items-center rounded-md flex opacity-0 w-full bg-[#1abc9ce6]  h-[100%] absolute top-0  left-0 z-10  group-hover:opacity-100 transition duration-500 cursor-pointer  ">
            <i className="  text-white text-[90px] fa-solid fa-plus"></i>
          </div>
        </div>
      </div>
    </div>
  );
}
