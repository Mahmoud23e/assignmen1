export default function Contact() {
  return (
    <>
      <div className="contact">
        <div className="top">
          <p className="text-center font-bold text-[40px] text-slate-700">
            CONATCT SECTION
          </p>
          <div className="star flex text-center justify-center mb-3 ">
            <div className="left w-[100px] h-1 bg-slate-700  rounded-md mt-2"></div>
            <i className="fa-solid fa-star mx-2"></i>
            <div className="left w-[100px] h-1 bg-slate-700  rounded-md mt-2"></div>
          </div>
        </div>

        <div className="form  w-[50%] mx-auto ">
          <div className="flex flex-col">
            <input
              type="text"
              className="border-none  shadow-md rounded-lg p-3 my-2  "
              placeholder="username"
            />
            <input
              type=" number "
              className="border-none  shadow-md rounded-lg p-3 my-2  "
              placeholder="userAge"
            />
            <input
              type=" email "
              className="border-none  shadow-md rounded-lg p-3 my-2  "
              placeholder="userEmail"
            />
            <input
              type="password"
              className="border-none  shadow-md rounded-lg p-3 my-2  "
              placeholder="UserPassword"
            />
            <button className=" w-[200px] bg-emerald-400 text-white rounded-lg  py-[10px] px-[30px] my-5  ">
              send message
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
