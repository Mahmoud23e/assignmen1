export default function About() {
  return (
    <>
      <div className=" text-white  bg-[#1abc9d] flex justify-center items-center text-center p-60 flex-col ]">
        <p className=" text-white font-bold text-[40px] ">ABOUT COMPONENT</p>
        <div className="star flex">
          <div className="left w-[100px] h-1 bg-white  rounded-md mt-2"></div>
          <i className="fa-solid fa-star mx-2"></i>
          <div className="left w-[100px] h-1 bg-white  rounded-md mt-2"></div>
        </div>

        <div className="par flex  gap-7 mt-4 text-start">
          <div className="left">
            <p>
              Freelancer is a free bootstrap theme created by Route. The
              download includes the complete source files including HTML, CSS,
              and JavaScript as well as optional SASS stylesheets for easy
              customization.
            </p>
          </div>
          <div className="right">
            <p>
              Freelancer is a free bootstrap theme created by Route. The
              download includes the complete source files including HTML, CSS,
              and JavaScript as well as optional SASS stylesheets for easy
              customization.
            </p>
          </div>
        </div>
      </div>
    </>
  );
}
