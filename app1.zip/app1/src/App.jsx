import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";
import "../../../yummy exam/css/all.min.css";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import About from "./components/About/About";
import Contact from "./components/contact/Contact";
import Portfolio from "./components/Portfolio/Portfolio";
import Layout from "./components/Layout/Layout";
import Home from "./home/Home";

function App() {
  const router = createBrowserRouter([
    {
      path: "",
      element: <Layout />,
      children: [
        { path: "about", element: <About /> },
        { path: "home", element: <Home /> },
        { path: "contact", element: <Contact /> },
        { path: "portfolio", element: <Portfolio /> },
        {
          path: "*",
          element: (
            <h2 className="h-screen flex justify-center items-center font-bold text-[70px]">
              {" "}
              error{" "}
            </h2>
          ),
        },
      ],
    },
  ]);
  return <RouterProvider router={router} />;
}

export default App;
