import portfolioimg from "../assets/images/avataaars.svg";

export default function Home() {
  return (
    <>
      <div className="portfolio w-full bg-[#1abc9d] flex justify-center items-center text-center p-40 flex-col">
        <div className="image w-[300px] ">
          <img src={portfolioimg} className=" w-full" alt="my image" />
        </div>
        <p className="text-white font-bold text-[45px] mt-2">START FRAMEWORK</p>
        <div className="star flex">
          <div className="left w-[100px] h-1 bg-white  rounded-md mt-2"></div>
          <i className="fa-solid fa-star text-white mx-2"></i>
          <div className="left w-[100px] h-1 bg-white  rounded-md mt-2"></div>
        </div>
        <p className=" text-white ">
          Graphic Artist - Web Designer - Illustrator
        </p>
      </div>
    </>
  );
}
